<template>
  <div>
    <h2>로그인 페이지 입니다.</h2>
    <LoginForm />
    
  </div>
</template>

<script>
import LoginForm from '@/components/LoginForm'

export default {
  name: 'Login',

  components: {
    LoginForm,
  },
  methods: {
  },
  props: {
    
  }
}
</script>

<style>

</style>